# Deploying to Hostinger (Node.js Web App)

Needs a Hostinger plan with **Node.js Web Apps** (Business / Cloud / VPS). Plain
"Premium/Single" shared hosting cannot run this app.

1. **Add the missing images** – see `MISSING-IMAGES.txt` (they lived on Lovable's CDN).
2. hPanel > Websites > Add Website > **Node.js Apps** > **Upload your website files** > upload this ZIP.
3. Settings (usually auto-detected):
   - Node version: **22.x**
   - Install command: `npm install`
   - Build command: `npm run build`
   - Start command: `npm start`
   - Entry file: `server.js`
4. Environment variables: `.env` is already included (public Supabase values). If you
   prefer, add the same six variables from `.env.example` in hPanel instead.
5. Deploy / Redeploy, then attach your domain and enable SSL.

Changed for Hostinger: build target switched from Cloudflare to Node (`vite.config.ts`),
added `npm start`, `server.js`, `.env`, `engines`, `.nvmrc`.
