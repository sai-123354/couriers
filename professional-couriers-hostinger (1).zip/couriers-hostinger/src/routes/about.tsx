import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { Shield, Truck, Users, Globe } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — The Professional Couriers — Piduguralla" },
      { name: "description", content: "40+ years of trusted domestic courier service across India. Learn about our mission, values, and nationwide network." },
      { property: "og:title", content: "About Professional Couriers — Piduguralla" },
      { property: "og:description", content: "India's most trusted domestic courier network with 19,000+ pincodes covered." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const values = [
    { icon: Shield, title: "Reliability", desc: "Every parcel handled with care and delivered on time, guaranteed." },
    { icon: Truck, title: "Nationwide Reach", desc: "19,000+ pincodes, 2,500+ branches across every Indian state." },
    { icon: Users, title: "Customer First", desc: "Dedicated support 7 days a week and real-time tracking updates." },
    { icon: Globe, title: "Scale", desc: "Handling 5 lakh+ shipments daily with industry-leading SLAs." },
  ];
  return (
    <PageLayout>
      <PageHero eyebrow="Our Story" title="Delivering trust across India for over 40 years." subtitle="From a single office to a nationwide logistics powerhouse — Professional Couriers is India's most established domestic courier network." />
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold">Our Mission</h2>
            <p className="mt-3 text-muted-foreground">To connect every Indian household and business with fast, affordable, and dependable courier services — powered by technology and a passionate on-ground team.</p>
            <h2 className="mt-8 text-2xl font-bold">Our Vision</h2>
            <p className="mt-3 text-muted-foreground">To be the most preferred logistics partner in India, known for professionalism, transparency, and unwavering commitment to service.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {values.map((v) => (
              <div key={v.title} className="card-elevated p-5">
                <v.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-3 font-semibold">{v.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
}