import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { Receipt, type ShipmentRow } from "@/components/receipt/Receipt";
import { Button } from "@/components/ui/button";
import { Printer, Download, ArrowLeft, Loader2 } from "lucide-react";

export const Route = createFileRoute("/receipt/$tracking")({
  head: ({ params }) => ({
    meta: [
      { title: `Receipt ${params.tracking} — The Professional Couriers — Piduguralla` },
      { name: "description", content: `Professional Couriers receipt for tracking number ${params.tracking}.` },
      { property: "og:title", content: `Receipt ${params.tracking} — Piduguralla` },
      { property: "og:description", content: "Printable Professional Couriers consignment note." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ReceiptPage,
});

function ReceiptPage() {
  const { tracking } = Route.useParams();
  const [row, setRow] = useState<ShipmentRow | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.from("shipments").select("*").eq("tracking_number", tracking).maybeSingle();
      if (error) setErr(error.message);
      else if (!data) setErr("Receipt not found");
      else setRow(data as ShipmentRow);
    })();
  }, [tracking]);

  return (
    <PageLayout>
      <section className="receipt-page mx-auto max-w-6xl px-4 pb-10 pt-32">
        <div className="no-print mb-6 flex flex-wrap items-center justify-between gap-3">
          <Button asChild variant="outline"><Link to="/book"><ArrowLeft className="mr-1 h-4 w-4" /> New booking</Link></Button>
          <div className="flex gap-2">
            <Button onClick={() => window.print()} className="btn-hero"><Printer className="mr-1 h-4 w-4" /> Print</Button>
            <Button onClick={() => window.print()} variant="outline"><Download className="mr-1 h-4 w-4" /> Save as PDF</Button>
          </div>
        </div>
        {err && <p className="rounded-lg bg-destructive/10 p-4 text-destructive">{err}</p>}
        {!row && !err && <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading receipt…</div>}
        {row && <Receipt s={row} />}
      </section>
    </PageLayout>
  );
}