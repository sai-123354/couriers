import { supabase } from "@/integrations/supabase/client";

export function generateTrackingCandidate() {
  const n = Math.floor(10000 + Math.random() * 90000);
  return `PDR${n}`;
}

export async function generateUniqueTracking(): Promise<string> {
  for (let i = 0; i < 8; i++) {
    const candidate = generateTrackingCandidate();
    const { data, error } = await supabase
      .from("shipments")
      .select("tracking_number")
      .eq("tracking_number", candidate)
      .maybeSingle();
    if (error) throw error;
    if (!data) return candidate;
  }
  throw new Error("Could not generate unique tracking number");
}

export function calcVolumetric(l: number, w: number, h: number) {
  const v = (l * w * h) / 5000;
  return Number.isFinite(v) ? Math.round(v * 100) / 100 : 0;
}

export const STATUS_STEPS = [
  "Booked",
  "Picked Up",
  "Dispatched",
  "Hub Received",
  "In Transit",
  "Out For Delivery",
  "Delivered",
] as const;
export type ShipmentStatus = (typeof STATUS_STEPS)[number];