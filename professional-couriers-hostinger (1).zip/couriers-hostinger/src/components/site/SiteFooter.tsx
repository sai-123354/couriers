import { Link } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { Mail, Phone, MapPin } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="no-print mt-24 bg-brand-surface text-on-brand/80">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-4">
        <div>
          <Logo light />
          <p className="mt-4 text-sm">
            Piduguralla's trusted courier partner. 30+ years of safe, on-time delivery across Andhra Pradesh and pan-India.
          </p>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold text-on-brand">Company</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/about" className="hover:text-on-brand">About Us</Link></li>
            <li><Link to="/services" className="hover:text-on-brand">Services</Link></li>
            <li><Link to="/branches" className="hover:text-on-brand">Branch Network</Link></li>
            <li><Link to="/faq" className="hover:text-on-brand">FAQ</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold text-on-brand">Services</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/book" className="hover:text-on-brand">Book Courier</Link></li>
            <li><Link to="/track" className="hover:text-on-brand">Track Shipment</Link></li>
            <li><Link to="/services" className="hover:text-on-brand">Air Cargo</Link></li>
            <li><Link to="/services" className="hover:text-on-brand">Surface Cargo</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold text-on-brand">Contact</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-2"><Phone className="h-4 w-4 shrink-0" /><div><a href="tel:+919490056001">+91 9490056001</a><br /><a href="tel:+917989166001">+91 7989166001</a></div></li>
            <li className="flex items-start gap-2"><Mail className="h-4 w-4 shrink-0" /><a className="break-all" href="mailto:venkata.medam@gmail.com">venkata.medam@gmail.com</a></li>
            <li>GSTIN: 37CGEPM1248J1Z9</li>
            <li className="flex items-start gap-2"><MapPin className="h-4 w-4 shrink-0" /> Main Road, Piduguralla, Palnadu Dist., AP — 522413</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-on-brand/10 py-4 text-center text-xs text-on-brand/60">
        © {new Date().getFullYear()} The Professional Couriers — Piduguralla. All rights reserved.
      </div>
    </footer>
  );
}
