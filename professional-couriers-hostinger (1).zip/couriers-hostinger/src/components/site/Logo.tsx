import logo from "@/assets/reference/tpc-logo-bg.png.asset.json";
import footerLogo from "@/assets/reference/footer-logo-white.png.asset.json";
export function Logo({ light = false }: { light?: boolean }) {
 return <span className="reference-logo"><img src={light ? footerLogo.url : logo.url} alt="The Professional Couriers — Piduguralla" /></span>;
}
