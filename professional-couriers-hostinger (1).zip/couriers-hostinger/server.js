// Hostinger "Entry file". Starts the production server created by `npm run build`.
// Hostinger supplies PORT automatically.
import "./.output/server/index.mjs";
