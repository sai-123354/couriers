
CREATE TABLE public.shipments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tracking_number text NOT NULL UNIQUE,
  airway_bill text NOT NULL,
  -- sender
  sender_name text NOT NULL,
  sender_gst text,
  sender_mobile text NOT NULL,
  sender_email text,
  sender_address text NOT NULL,
  sender_city text NOT NULL,
  sender_state text NOT NULL,
  sender_pincode text NOT NULL,
  -- receiver
  receiver_name text NOT NULL,
  receiver_mobile text NOT NULL,
  receiver_email text,
  receiver_address text NOT NULL,
  receiver_city text NOT NULL,
  receiver_state text NOT NULL,
  receiver_pincode text NOT NULL,
  -- parcel
  contents text NOT NULL,
  pieces integer NOT NULL DEFAULT 1,
  declared_value numeric NOT NULL DEFAULT 0,
  actual_weight numeric NOT NULL DEFAULT 0,
  length numeric NOT NULL DEFAULT 0,
  width numeric NOT NULL DEFAULT 0,
  height numeric NOT NULL DEFAULT 0,
  volumetric_weight numeric NOT NULL DEFAULT 0,
  shipment_type text NOT NULL,
  transport_mode text NOT NULL,
  -- payment
  courier_charges numeric NOT NULL DEFAULT 0,
  gst_amount numeric NOT NULL DEFAULT 0,
  other_charges numeric NOT NULL DEFAULT 0,
  total_amount numeric NOT NULL DEFAULT 0,
  payment_mode text NOT NULL,
  -- status
  status text NOT NULL DEFAULT 'Booked',
  branch_name text NOT NULL DEFAULT 'Head Office',
  booking_date timestamptz NOT NULL DEFAULT now(),
  estimated_delivery timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.shipments TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.shipments TO authenticated;
GRANT ALL ON public.shipments TO service_role;

ALTER TABLE public.shipments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create a shipment"
  ON public.shipments FOR INSERT TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can read shipments"
  ON public.shipments FOR SELECT TO anon, authenticated
  USING (true);

CREATE INDEX shipments_tracking_idx ON public.shipments(tracking_number);
